function toggleMenu() {
    const navMenu = document.getElementById('navMenu');
    if (window.innerWidth <= 768) {
        navMenu.style.height = (navMenu.style.height == '250px') ? '0' : '250px';
    }
}
window.addEventListener('resize', () => {
    const navMenu = document.getElementById('navMenu');
    if (window.innerWidth > 768) {
        navMenu.style.height = '';
    }
});
